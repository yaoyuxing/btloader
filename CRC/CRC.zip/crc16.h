#ifndef  CRC_16_H
#define CRC_16_H


unsigned short usCrc16 (unsigned char *pucMsg,unsigned short usDataLen);

#endif  
